<?php  
if( ! defined( 'ABSPATH' ) ){
    exit; // Exit if accessed directly
}


echo '<div class="panel panel-view-options" style="display: none;"><div class="mfn-form mfn-form-options">';
              
echo '</div></div>';