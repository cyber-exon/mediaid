<?php
	defined( 'ABSPATH' ) || exit;
?>

<div id="mfn-dashboard" class="mfn-ui mfn-dashboard" data-page="dashboard">

	<div class="mfn-wrapper">

    This feature is disabled in White Label mode.

  </div>

</div>
